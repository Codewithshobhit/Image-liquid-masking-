# Image liquid masking 

A Pen created on CodePen.io. Original URL: [https://codepen.io/Codewithshobhit/pen/MWxwxEG](https://codepen.io/Codewithshobhit/pen/MWxwxEG).

Wouldn't be possible without iconic WebGL Fluid Simulation by Pavel Dobryakov: 
https://codepen.io/PavelDoGreat/pen/zdWzEL